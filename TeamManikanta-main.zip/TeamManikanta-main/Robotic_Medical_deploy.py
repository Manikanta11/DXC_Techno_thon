import streamlit as st
import os
from tensorflow import keras 
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Conv2D, MaxPooling2D, Flatten, Dense, Dropout, BatchNormalization
from PIL import Image
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.pyplot import imshow
plt.style.use('dark_background')
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder
import tensorflow as tf
bt=tf.keras.models.load_model('C:/Users/pkm8/Downloads/Brain_tumor_pred.h5')
osteo=tf.keras.models.load_model('C:/Users/pkm8/Downloads/Osteoporosis_73.h5')
covid=tf.keras.models.load_model('C:/Users/pkm8/Downloads/covid.h5')
pnue=tf.keras.models.load_model('C:/Users/pkm8/Downloads/pnuemonia_89.74_CNN_model.h5')

def names_brain(number,res,classification):
    confidence=res[0][classification]*100
    if number==1 and confidence>0:
        return str(confidence)+' %Confidence Its a Tumor'
        
    else:
        return 'Its not a tumor'

data_brain=st.file_uploader('Upload Brain Image in JPG',type=['jpg'])
print(data_brain)

def names_knee(number):
    confidence=number*100
    if number==1 and confidence>0:
        return str(confidence)+'% Confidence knee osteoporosis'
    else:
        return 'Its not a knee osteoporosis'

def covid_or_not(number):
    confidence=number*100
    if number==1 and confidence>0:
        return str(confidence)+'% Confidence this is Covid'
    else:
        return 'Its not a Covid'

def names_pnue(result):
    if result[0][0] > 0.5:
       prediction = 'Pnuemonia'
    else:
       prediction = 'Normal'
    return prediction

if(data_brain is not None ):
    img=Image.open(data_brain)
    x = np.array(img.resize((32,32)))
    x= x.reshape(1,32,32,3)
    res = bt.predict(x)
    classification = np.where(res == np.amax(res))[1][0]
    result=int(res[0])
    #st.markdown(imshow(img))
    st.image(img)
    conf=names_brain(result,res,classification)
    st.title(conf)
    #st.markdown(names(classification)'''
    import cv2
    #imshow(img)
    print(names_brain(result,res,classification))

    if conf!='Its not a tumor':
        img_array=np.array(img.resize((250,250)))
        gray = cv2.cvtColor(img_array, cv2.COLOR_BGR2GRAY, 0.7)
        #st.image(gray, width=100)
        (T, thresh) = cv2.threshold(gray, 155, 255, cv2.THRESH_BINARY)
        #st.image(thresh)
        (T, threshInv) = cv2.threshold(gray, 155, 255,cv2.THRESH_BINARY_INV)
        #st.image(threshInv)
        kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (10, 5))
        closed = cv2.morphologyEx(thresh, cv2.MORPH_CLOSE, kernel)
        st.image([thresh,threshInv,closed],width=200)

data_osteo=st.file_uploader('Upload Knee Osteoporosis Image in JPG',type=['jpg'])

if(data_osteo is not None ):
    img=Image.open(data_osteo)
    x = np.array(img.resize((100,100)))
    x= x.reshape(1,100,100,3)
    res = osteo.predict(x)
    classification = np.where(res == np.amax(res))[1][0]
    #st.markdown(imshow(img))
    st.image(img)
    conf=names_knee(classification)
    st.title(conf)
    #st.markdown(names(classification)'''
    import cv2
    #imshow(img)
    print(names_knee(classification))

    if conf!='Its not a knee osteoporosis':
        img_array=np.array(img.resize((100,100)))
        gray = cv2.cvtColor(img_array, cv2.COLOR_BGR2GRAY, 0.7)
        #st.image(gray, width=100)
        (T, thresh) = cv2.threshold(gray, 155, 255, cv2.THRESH_BINARY)
        #st.image(thresh)
        (T, threshInv) = cv2.threshold(gray, 155, 255,cv2.THRESH_BINARY_INV)
        #st.image(threshInv)
        kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (10, 5))
        closed = cv2.morphologyEx(thresh, cv2.MORPH_CLOSE, kernel)
        st.image([thresh,threshInv,closed],width=200)

data_covid=st.file_uploader('Upload Lungs MRI to Check covid in png',type=['png'])

if(data_covid is not None ):
    img=Image.open(data_covid)
    x = np.array(img.resize((200,200)))
    x= x.reshape(1,200,200,3)
    res = covid.predict(x)[0]
    #classification = np.where(res == np.amax(res))[1][0]
    #st.markdown(imshow(img))
    st.image(img)
    conf=covid_or_not(res)
    st.title(conf)
    #st.markdown(names(classification)'''
    import cv2
    #imshow(img)
    print(covid_or_not(res))

    if conf!='Its not a Covid':
        img_array=np.array(img.resize((200,200)))
        gray = cv2.cvtColor(img_array, cv2.COLOR_BGR2GRAY, 0.7)
        #st.image(gray, width=100)
        (T, thresh) = cv2.threshold(gray, 155, 255, cv2.THRESH_BINARY)
        #st.image(thresh)
        (T, threshInv) = cv2.threshold(gray, 155, 255,cv2.THRESH_BINARY_INV)
        #st.image(threshInv)
        kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (10, 5))
        closed = cv2.morphologyEx(thresh, cv2.MORPH_CLOSE, kernel)
        st.image([thresh,threshInv,closed],width=200)

data_pnue=st.file_uploader('Upload Lungs MRI to check pneumonia in png',type=['jpeg'])

if(data_pnue is not None ):
    img=Image.open(data_pnue)
    x = np.array(img.resize((64,64)))
    x= x.reshape(1,64,64,3)
    res=pnue.predict(x)
    #classification = np.where(res == np.amax(res))[1][0]
    #st.markdown(imshow(img))
    st.image(img)
    conf=names_pnue(res)
    st.title(conf)
    #st.markdown(names(classification)'''
    import cv2
    #imshow(img)
    print(names_pnue(res))

    if conf!='Normal':
        img_array=np.array(img.resize((200,200)))
        gray = cv2.cvtColor(img_array, cv2.COLOR_BGR2GRAY, 0.7)
        #st.image(gray, width=100)
        (T, thresh) = cv2.threshold(gray, 155, 255, cv2.THRESH_BINARY)
        #st.image(thresh)
        (T, threshInv) = cv2.threshold(gray, 155, 255,cv2.THRESH_BINARY_INV)
        #st.image(threshInv)
        kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (10, 5))
        closed = cv2.morphologyEx(thresh, cv2.MORPH_CLOSE, kernel)
        st.image([thresh,threshInv,closed],width=200)